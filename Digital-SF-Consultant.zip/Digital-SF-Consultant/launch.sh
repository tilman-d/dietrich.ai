#!/bin/sh

streamlit run app.py --server.headless true