import os
import streamlit as st
import openai
from openai import AssistantEventHandler
from typing_extensions import override
from dotenv import load_dotenv

load_dotenv()

# Set page config
st.set_page_config(page_title="Transparent Chatbot", layout="wide")

# Custom CSS to make background transparent and adjust text colors
st.markdown("""
    <style>
    [data-testid="stHeader"] {
        display: none;
    }
    </style>
    """,
            unsafe_allow_html=True)

# Load environment variables
openai_api_key = os.environ.get("OPENAI_API_KEY")
assistant_id = os.environ.get("ASSISTANT_ID")
assistant_title = os.environ.get("ASSISTANT_TITLE", "Transparent Chatbot")

client = openai.OpenAI(api_key=openai_api_key)


class EventHandler(AssistantEventHandler):

    @override
    def on_text_created(self, text):
        st.session_state.current_message = ""
        with st.chat_message("Assistant"):
            st.session_state.current_markdown = st.empty()

    @override
    def on_text_delta(self, delta, snapshot):
        if snapshot.value:
            st.session_state.current_message = snapshot.value
            st.session_state.current_markdown.markdown(
                st.session_state.current_message, True)

    @override
    def on_text_done(self, text):
        st.session_state.current_markdown.markdown(text.value, True)
        st.session_state.chat_log.append({
            "name": "assistant",
            "msg": text.value
        })


def create_thread():
    return client.beta.threads.create()


def create_message(thread, content):
    client.beta.threads.messages.create(thread_id=thread.id,
                                        role="user",
                                        content=content)


def run_stream(user_input):
    if "thread" not in st.session_state:
        st.session_state.thread = create_thread()
    create_message(st.session_state.thread, user_input)
    with client.beta.threads.runs.stream(
            thread_id=st.session_state.thread.id,
            assistant_id=assistant_id,
            event_handler=EventHandler(),
    ) as stream:
        stream.until_done()


def render_chat():
    for chat in st.session_state.chat_log:
        with st.chat_message(chat["name"]):
            st.markdown(chat["msg"], True)


if "chat_log" not in st.session_state:
    st.session_state.chat_log = []


def main():
    st.title(assistant_title)
    user_msg = st.chat_input("Message")

    if user_msg:
        render_chat()
        with st.chat_message("user"):
            st.markdown(user_msg, True)
        st.session_state.chat_log.append({"name": "user", "msg": user_msg})

        run_stream(user_msg)
        st.rerun()

    render_chat()


if __name__ == "__main__":
    main()
