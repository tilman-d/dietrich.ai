# example function
def example_function(address):
    pass


TOOL_MAP = {"example_function": example_function}
